#ifndef __utilities_Modbus_H__
#define __utilities_Modbus_H__

#include <inttypes.h>

uint16_t crc16(const uint8_t *ptr, uint16_t len);

#endif // __utilities_Modbus_H__
